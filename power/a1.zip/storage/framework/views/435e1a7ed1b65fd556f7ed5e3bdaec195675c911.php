<?php $__env->startSection('content'); ?>
<section class="cstm-cart-section">
  <div class="container">
    <div class="row">
      
      <?php echo $__env->make('layouts.front.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <?php if(@$carts && !$carts->isEmpty()): ?>
      <div class="cstm-cart">
        <h4><?php echo e(__('My Cart')); ?></h4>
       <div class="cart_p_cont">
        <table class="item-table">
          <thead>
            <tr>
              <th>Remove</th>
              <th>Image</th>
              <th>Course Name</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            <?php ($total = 0); ?>
            <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>
                <a data-method="Delete" data-confirm="Are you sure?" href="<?php echo e(route('cart.destroy', $cart->id)); ?>" title="Remove from cart">
                  <img src="<?php echo e(asset('images/cart-cut.png')); ?>">
                </a>
              </td>
              <td class="cart=thumbnails">
                <?php if($cart->programs->image): ?>
                <a href="<?php echo e(route('program.preview', [$cart->programs->slug])); ?>">
                  <img class="cart_table_img" src="<?php echo e(asset('uploads/programs/small/'.$cart->programs->image)); ?>">
                </a>
                <?php endif; ?>
              </td>
              <td>
                <a href="<?php echo e(route('program.preview', [$cart->programs->slug])); ?>">
                <?php echo e($cart->programs->title); ?>

                </a>
              </td>
              <td>$<?php echo e($cart->programs->price); ?></td>
              <?php ($total = $total + $cart->programs->price); ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>


        <div class="cart_total_outr pull-right">
          <a class="total_amount" href="javascript:void(0)">
            <?php echo e(__('Total')); ?> : $ <?php echo e($total); ?>

          </a>
        </div>

        <div class=" pull-right cart_btns_outr">
          <a class="cart_pg_btn cont_ship_btn" href="<?php echo e(route('program.index')); ?>">
          <?php echo e(__('Add programs')); ?>

          </a>
          <a class="cart_pg_btn checkout_btn" href="javascript:void(0)" onclick="event.preventDefault(); document.getElementById('checkout-form').submit();">
          <?php echo e(__('Checkout')); ?>

          </a>
          <form id="checkout-form" action="<?php echo e(route('cart.payment')); ?>" method="POST" style="display: none;">
          <?php echo csrf_field(); ?>
          </form>
        </div>
        
      </div>
      <?php else: ?>
      <div class="empty-cart">
        <h4><?php echo e(__('your cart is empty, click here to continue')); ?></h4>
        <a class="checkout_btn" href="<?php echo e(route('program.index')); ?>">
          <?php echo e(__('Add programs')); ?>

        </a>
      </div>
      <?php endif; ?>
    </div>
  </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>