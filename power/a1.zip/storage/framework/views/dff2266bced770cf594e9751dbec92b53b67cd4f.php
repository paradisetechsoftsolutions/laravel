<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box box-form">
                <div class="box-header">
                    <h3 class="box-title">Show <?php echo e($title); ?></h3>
                    <a href="<?php echo e(route('programs.index')); ?>" class="btn btn-success pull-right"><i class="fa fa-arrow-left"></i> Back</a>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="col-md-12">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e($program->title); ?></h3>
                            <div class="pull-right">		                        

		                        <?php if($program->active =='1'): ?>
	                            <button class="btn btn-success">Active</button>
	                            <?php else: ?>
		                        <button class="btn btn-danger">De-active</button>
		                        <?php endif; ?>

		                        <a href="<?php echo e(route('programs.edit', $program->id)); ?>" class="btn btn-warning"><i class="fa fa-edit"></i> Edit</a>

		                        <a href="<?php echo e(route('modules.index', $program->id)); ?>" class="btn btn-success">Module</a>

	                    	</div>
                        </div>
						<div class="col-md-8">
							<strong>Price</strong>
							<p>$ <?php echo e($program->price); ?>/-</p>
							<strong>Short Video Link</strong>
							<p><a href="<?php echo e($program->short_video); ?>"><?php echo e($program->short_video); ?></a></p>
							<strong>Video Link</strong>
							<p><a href="<?php echo e($program->video); ?>"><?php echo e($program->video); ?></a></p>
						</div>
						<div class="col-md-4">
							<span class="show-image pull-right">
								<img src="<?php echo e(asset('uploads/programs/small/'.$program->image)); ?>">
							</span>
						</div>

						<div class="col-md-12">
	                        <strong>Description</strong>
	                        <p><?php echo $program->description; ?></p>
						</div>
                        
                    </div>
                </div>
                <!-- /.box-body -->
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>