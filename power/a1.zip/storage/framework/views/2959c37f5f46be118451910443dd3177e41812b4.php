<?php $__env->startSection('content'); ?>
<section class="sub-banner">
	<div class="feature-image">
		<img src="<?php echo e(asset('images/our-program-bg.jpg')); ?>">
		<h4><?php echo e(__('Our programs')); ?></h4>
	</div>
</section>
<section class="success-stories-page our-program">
	<div class="container">
		<div class="row">
			<?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-12 col-sm-6 col-md-6">
				<div class="prog-item ">
					<div class="img-layer">
						<?php if($program->image): ?>
						<img src="<?php echo e(asset('uploads/programs/'.$program->image)); ?>">
						<?php endif; ?>
						<div class="prog-btn">
	                        <a href="javascript:void(0)"><?php echo e($program->title); ?></a>
	                      </div>
						<div class="prog-hover">
							<div class="hvr-inner">
								<a href="<?php echo e(route('program.preview', [$program->slug])); ?>"><?php echo e(__('View Program Preview')); ?></a>
								<a href="javascript:void(0)" onclick="buyProgram(`<?php echo e($program->id); ?>`)">
								<?php echo e(__('Buy the Program')); ?>

								</a>								
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</section>

<form id="buynow-form" action="<?php echo e(route('cart.store')); ?>" method="POST" style="display: none;">
	<?php echo csrf_field(); ?>
	<input type="hidden" name="users_id" value="<?php echo e(Auth::user()->id); ?>">	
</form>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script>
function buyProgram(id){
	var $form = '#buynow-form';
	jQuery($form).append('<input type="hidden" name="programs_id" value="'+id+'">');
	jQuery($form).submit();
}
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>