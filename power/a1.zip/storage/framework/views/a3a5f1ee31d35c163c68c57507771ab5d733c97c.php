<?php $__env->startSection('content'); ?>
<section class="main-course main-video-lesson cstm-cont-outer">
   <div class="container-fluid">
      <div class="row">
         <div class="col-12 col-sm-8 col-md-8">
            
            <?php if($chapter): ?>
               <div class="left-video-bar">
                  <?php if($chapter->video): ?>
                  <div class="videos-item-frame">                     
                     <iframe width="100%" height="315" src="<?php echo e($chapter->video); ?>?autoplay=1" frameborder="0" allowfullscreen></iframe>
                  </div>
                  <?php endif; ?>
                  <div class="rate-this-course">
                     <label>Rate this course :</label> <a href="#"><i class="fa fa-thumbs-o-up" aria-hidden="true"></i></a> <a href="#"><i class="fa fa-thumbs-o-down" aria-hidden="true"></i></a>
                  </div>
                  <div class="video-inf">
                     <h3><?php echo e($chapter->title); ?></h3>



                     <?php echo $chapter->description; ?>

                  </div>
               </div>
            <?php else: ?>
               <div class="left-video-bar">
                  <div class="videos-item-frame">                     
                     <iframe width="100%" height="315" src="<?php echo e($program->video); ?>?autoplay=1" frameborder="0" allowfullscreen></iframe>
                  </div>
                  <div class="rate-this-course">
                     <label>Rate this course :</label> <a href="#"><i class="fa fa-thumbs-o-up" aria-hidden="true"></i></a> <a href="#"><i class="fa fa-thumbs-o-down" aria-hidden="true"></i></a>
                  </div>
                  <div class="video-inf">
                     <h3><?php echo e($program->title); ?></h3>
                     <?php echo $program->description; ?>

                  </div>
               </div>
            <?php endif; ?>

         </div>
         <div class="col-12 col-sm-4 col-md-4 rvb">
            <div class="right-video-bar">
               <h5>All Videos</h5>
               
               <?php $__currentLoopData = $program->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $module_rel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="video-play-list">
                  <div class="panel-heading">
                     <h6 class="panel-title">
                        <a href="#module-<?php echo e($module_rel->id); ?>" data-toggle="collapse" class="<?php echo e((@$module->slug==$module_rel->slug)?'':'collapsed'); ?>" aria-expanded="<?php echo e(@($module->slug==$module_rel->slug)?'true':'false'); ?>"><?php echo e($module_rel->title); ?>

                        <i class="fa fa-plus" aria-hidden="true"></i>
                        <i class="fa fa-minus" aria-hidden="true"></i>
                        </a>
                     </h6>
                  </div>
                  <div id="module-<?php echo e($module_rel->id); ?>" class="panel-collapse collapse ul-list-vid <?php echo e((@$module->slug==$module_rel->slug)?'show':''); ?>">
                     <div class="panel-body">
                        <ul>
                        	<?php $__currentLoopData = $module_rel->chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter_rel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        	<li class="<?php echo e((@$module->slug==$module_rel->slug)?'active':''); ?>">
                              <a href="<?php echo e(route('program.videos.view', [$program->slug, $module_rel->slug, $chapter_rel->slug])); ?>">
                                 <i class="fa fa-check" aria-hidden="true"></i>
                                 <?php echo e($chapter_rel->title); ?>

                              </a>
                           </li>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                     </div>
                  </div>
               </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
         </div>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>