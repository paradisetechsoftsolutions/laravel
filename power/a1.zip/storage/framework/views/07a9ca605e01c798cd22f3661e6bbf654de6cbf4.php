<div class="copy-right">
    © Copyright  The Powerhouse Within You 2018   |   ALL RIGHTS RESERVED  
</div>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('js/delete.js')); ?>"></script>
<script>var BASE_URL = jQuery('meta[name="site-url"]').attr('content');</script> 
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>