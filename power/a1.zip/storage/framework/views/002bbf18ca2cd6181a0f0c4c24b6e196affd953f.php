<?php $__env->startSection('content'); ?>
<section class="home-video">
	<div class="vid-sec">
		<iframe width="100%" height="100%" src="<?php echo e($program->short_video); ?>?autoplay=1" frameborder="0" allowfullscreen></iframe>
	</div>
	<div class="vid-caption">
		<h2><?php echo e($program->title); ?></h2>
	</div>
</section>

<section class="main-course">
	<div class="container">
		<div class="crs-heading">
			<h2>main course</h2>
		</div>
		<div class="row">
			<div class="col-12 col-sm-6 col-md-6">
				<div class="csr-image">
					<?php if($program->image): ?>
					<img src="<?php echo e(asset('uploads/programs/'.$program->image)); ?>">
					<?php endif; ?>
				</div>
			</div>
			<div class="col-12 col-sm-6 col-md-6">
				<div class="buy-acadmy">
					<h3><?php echo e($program->title); ?></h3>
					<div class="crs-descri">
						<?php echo $program->description; ?>

					</div>
					<div class="buy-btn-crs">

						<a class="universal-btn" href="<?php echo e(route('cart.store')); ?>" onclick="event.preventDefault(); document.getElementById('buynow-form').submit();">
						<?php echo e(__('buy now')); ?>

						</a>

						<form id="buynow-form" action="<?php echo e(route('cart.store')); ?>" method="POST" style="display: none;">
							<?php echo csrf_field(); ?>
							<input type="hidden" name="users_id" value="<?php echo e(Auth::user()->id); ?>">
							<input type="hidden" name="programs_id" value="<?php echo e($program->id); ?>">
						</form>

					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>