<?php

namespace power\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class ProgramsRequest extends FormRequest
{
    /**
    * Determine if the user is authorized to make this request.
    *
    * @return bool
    */
    public function authorize()
    {
        return true;
    }

    /**
    * Get the validation rules that apply to the request.
    *
    * @return array
    */
    public function rules()
    {
        switch($this->method())
        {
            case 'GET':
            case 'DELETE':
            {
                return [];
            }
            case 'POST':
            {
                return [
                    'title' => 'required|unique:programs,title|max:150',
                    'price' => 'required|numeric',
                    'image' => 'required|mimetypes:image/jpeg,image/png,image/jpg|max:1024',
                    'short_video' => 'required|max:255',
                    'video' => 'required|max:255',
                    'description' => 'required',
                    'active' => 'required'
                ];
            }
            case 'PUT':
            case 'PATCH':
            {
                return [
                    'title' => 'required|unique:programs,title,'.$this->program->id.'|max:150',
                    'price' => 'required|numeric',
                    'image' => 'mimetypes:image/jpeg,image/png,image/jpg|max:1024',
                    'short_video' => 'required|max:255',
                    'video' => 'required|max:255',
                    'description' => 'required',
                    'active' => 'required'
                ];
            }
            default:break;
        }
    }



}