$(function () {
    $('.pickadate').pickadate();
});