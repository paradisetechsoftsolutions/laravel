@include('layouts.front.header')
@include('layouts.front.body')
@include('layouts.front.footer')