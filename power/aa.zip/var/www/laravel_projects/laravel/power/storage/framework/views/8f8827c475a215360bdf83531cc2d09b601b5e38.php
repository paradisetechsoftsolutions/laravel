	    </div>

    	<script src="<?php echo e(asset('admin/vendor/jQuery/jquery-2.2.3.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/vendor/jquery-fullscreen/jquery.fullscreen-min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/vendor/slimScroll/jquery.slimscroll.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/vendor/fastclick/fastclick.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/vendor/chartjs/Chart.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/vendor/sparkline/jquery.sparkline.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/resources/js/app.min.js')); ?>"></script>

        <script src="<?php echo e(asset('admin/resources/js/demo.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/resources/js/pages/dashboard.js')); ?>"></script>
        <script src="<?php echo e(asset('js/delete.js')); ?>"></script>
        <script src="<?php echo e(asset('js/custom.js')); ?>"></script>

        <?php echo $__env->yieldContent('script'); ?>

    </body>

</html>