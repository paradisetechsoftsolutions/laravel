<div class="col-md-3 left_Sectnss">
    <ul class="profile_data">

        <li class="<?php echo e(($active=='profile')?'active':''); ?>"><a href="<?php echo e(route('settings.profile')); ?>">Profile</a></li>

        <li class="<?php echo e(($active=='admin')?'active':''); ?>"><a href="<?php echo e(route('settings.admin')); ?>">Account</a></li>

        <li class="<?php echo e(($active=='notifications')?'active':''); ?>"><a href="<?php echo e(route('settings.notifications')); ?>">Notifications</a></li>

        <li class="<?php echo e(($active=='programs')?'active':''); ?>"><a href="<?php echo e(route('settings.programs')); ?>">My Programs</a></li>

        <li class="<?php echo e(($active=='billing')?'active':''); ?>"><a href="<?php echo e(route('settings.billing')); ?>">Payment History</a></li>

    </ul>
</div>