<?php $__env->startSection('content'); ?>
<section id="login-form" class="login-info-main">
    <div class="abt-login">
        <div class="login-logo">
            <a href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('images/logo.png')); ?>">
            </a>
        </div>
        <div class="inner-login">
            <h3><?php echo e(__('Login')); ?></h3>
            
            <form method="POST" class="form-horizontal" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <input type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" placeholder="<?php echo e(__('E-Mail Address')); ?>" value="<?php echo e(old('email')); ?>" required autofocus>
                    <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <input type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="<?php echo e(__('Password')); ?>" required>
                    <?php if($errors->has('password')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <input class="form-check-input" type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="remember">
                        <?php echo e(__('Remember Me')); ?>

                    </label>
                </div>

                <div class="form-group btn-grp">
                    <div class="login-btn">
                        <button type="submit" class="btn btn-default"><?php echo e(__('Login')); ?></button>
                    </div>
                </div>
            </form>

            <div class="create-account-info">
                <ul>
                    <li>
                        <a href="<?php echo e(route('register')); ?>"><?php echo e(__('Create an Account')); ?></a>
                    </li>
                    <li>
                        <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>"><?php echo e(__('Forgot Password?')); ?></a>
                    </li>
                </ul>
            </div>

            <div class="social-icon">
                <ul>
                    <li>
                        <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-vimeo-square" aria-hidden="true"></i></a>
                    </li>
                </ul>
            </div>
            
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>