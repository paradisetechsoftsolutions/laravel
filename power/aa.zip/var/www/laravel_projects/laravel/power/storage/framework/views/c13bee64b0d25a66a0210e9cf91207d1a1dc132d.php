<?php echo Form::hidden('program_id', $program->id); ?>

<?php echo Form::hidden('module_id', $module->id); ?>


<div class="form-group <?php echo ($errors->has('title') ? 'has-error' : ''); ?>">
    <?php echo Form::label('title','Title', ['class' => 'control-label']); ?>

    <?php echo Form::text('title', null, ['class' => 'form-control' . ($errors->has('title') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('title', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('description') ? 'has-error' : ''); ?>">
    <?php echo Form::label('description','Description', ['class' => 'control-label']); ?>

    <?php echo Form::textarea('description', null, ['class' => 'form-control' . ($errors->has('description') ? ' is-invalid' : ''), 'rows' => '4' ]); ?>

    <?php echo $errors->first('description', '<span class="help-block">:message</span>'); ?>

</div>

<?php if($check=='edit'): ?>
    <?php $__currentLoopData = $chapter->chaptersupload; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upload): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-group"><hr>
            <label><?php echo e($upload->type); ?></label><br>
            <span class="pull-right deleteThis" data-type="<?php echo e($upload->type); ?>" data-id="<?php echo e($upload->id); ?>" data-value="<?php echo e($upload->name); ?>"><i class="fa fa-trash"></i></span>
            <?php if($upload->type=='video'): ?>
                <iframe width="100%" height="345" src="<?php echo e($upload->name); ?>" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
                <input type="hidden" data-type="video" name="videos[]" value="<?php echo e($upload->name); ?>">
            <?php elseif($upload->type=='image'): ?>
                <img src="<?php echo e(asset('uploads/chapters/images/'.$upload->name)); ?>">
                <input type="hidden" data-type="images" name="images[]" value="<?php echo e($upload->name); ?>">
            <?php elseif($upload->type=='file'): ?>    
                <a href="<?php echo e(asset('uploads/chapters/files/'.$upload->name)); ?>"><?php echo e($upload->name); ?></a>
                <input type="hidden" data-type="files" name="filesdata[]" value="<?php echo e($upload->name); ?>">
            <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<div id="add_new_chart"></div>

<hr>
<div class="form-group">
    <?php echo Form::label('Add New Chart','Add New Chart', ['class' => 'control-label']); ?>

</div>
<div class="form-group">
    <button type="button" class="btn btn-danger" onclick="newChart('video')"><i class="fa fa-youtube-play"></i> Add Video</button>
    <button type="button" class="btn btn-warning" onclick="newChart('image')"><i class="fa fa-picture-o"></i> Add Image</button>
    <button type="button" class="btn btn-info" onclick="newChart('file')"><i class="fa fa-paperclip"></i> Add File</button>
</div> 
<hr>

<div class="form-group <?php echo ($errors->has('active') ? 'has-error' : ''); ?>">
    <?php echo Form::label('active','Active', ['class' => 'control-label']); ?></br>
    <?php echo Form::radio('active', 1); ?> Yes
    <?php echo Form::radio('active', 0); ?> No
    <?php echo $errors->first('active', '<span class="help-block">:message</span>'); ?>

</div>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/chapter_chart.js')); ?>"></script>
<?php $__env->stopSection(); ?>