
<?php echo Form::hidden('program_id', $program_id); ?>


<div class="form-group <?php echo ($errors->has('title') ? 'has-error' : ''); ?>">
    <?php echo Form::label('title','Title', ['class' => 'control-label']); ?>

    <?php echo Form::text('title', null, ['class' => 'form-control' . ($errors->has('title') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('title', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('description') ? 'has-error' : ''); ?>">
    <?php echo Form::label('description','Description', ['class' => 'control-label']); ?>

    <?php echo Form::textarea('description', null, ['class' => 'form-control' . ($errors->has('description') ? ' is-invalid' : ''), 'rows' => '4' ]); ?>

    <?php echo $errors->first('description', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('active') ? 'has-error' : ''); ?>">
    <?php echo Form::label('active','Active', ['class' => 'control-label']); ?></br>
    <?php echo Form::radio('active', 1); ?> Yes
    <?php echo Form::radio('active', 0); ?> No
    <?php echo $errors->first('active', '<span class="help-block">:message</span>'); ?>

</div>