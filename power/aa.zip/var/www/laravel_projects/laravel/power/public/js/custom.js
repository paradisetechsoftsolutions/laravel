(function() {
	//hide alerts
	setTimeout(function() { 
	   $('.alert').fadeOut(1000);
	}, 5000);
	
})();
