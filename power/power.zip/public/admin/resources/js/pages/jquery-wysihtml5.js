$(function () {
    $('.wysihtml5').wysihtml5();
});