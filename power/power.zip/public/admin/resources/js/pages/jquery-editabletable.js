$(function () {
    $('.editableTable').editableTableWidget();
});