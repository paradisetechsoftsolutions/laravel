$(function () {
    $('.icheck_flat_20').iCheck({
        checkboxClass: 'icheckbox_flat',
        increaseArea: '20%'
    });

    $('.icheck_flat_blue').iCheck({
        checkboxClass: 'icheckbox_flat-blue',
    });
});

            