<?php if(Session::has('success')): ?>
    <div class="alert alert-success alert-dismissable" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
        <?php echo e(Session::get('success')); ?>

    </div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
    <div class="alert alert-danger alert-dismissable" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
        <?php echo e(Session::get('error')); ?>

    </div>
<?php endif; ?>

<?php echo $__env->yieldContent('content'); ?>
