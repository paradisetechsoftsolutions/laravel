<?php $__env->startSection('content'); ?>
<section id="login-form" class="login-info-main">
    <div class="abt-login">
        <div class="login-logo">
            <a href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('images/logo.png')); ?>">
            </a>
        </div>
        <div class="inner-login">
            <h3><?php echo e(__('Register')); ?></h3>
            
            <form method="POST" class="form-horizontal" action="<?php echo e(route('register')); ?>" aria-label="<?php echo e(__('Register')); ?>">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <input type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" placeholder="<?php echo e(__('Your Name')); ?>" value="<?php echo e(old('name')); ?>" required autofocus>
                    <?php if($errors->has('name')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <input type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" placeholder="<?php echo e(__('E-Mail Address')); ?>" value="<?php echo e(old('email')); ?>" required autofocus>
                    <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="form-group btn-grp">
                    <div class="login-btn">
                        <button type="submit" class="btn btn-default"><?php echo e(__('Register')); ?></button>
                    </div>
                </div>
            </form>


            <div class="social-icon">
                <ul>
                    <li>
                        <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-vimeo-square" aria-hidden="true"></i></a>
                    </li>
                </ul>
            </div>
            
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>