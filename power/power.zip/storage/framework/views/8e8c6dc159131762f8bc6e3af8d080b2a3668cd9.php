<?php $__env->startSection('content'); ?>
<section class="main-course details-section">
	<div class="container">
		<div class="row">
			<div class="col-12 col-sm-6 col-md-6 revrsr-div">
				<div class="csr-image">
					<img src="<?php echo e(asset('images/crowd-image.jpg')); ?>">
					<div class="crowd-caption">
						<h3><?php echo e($program->title); ?></h3>
						<div class="buy-btn-crs">
							<a class="universal-btn" href="<?php echo e(route('program.videos', [$program->slug])); ?>">video lesson</a>
						</div>
						<div class="playcrown-vid">
							<img src="<?php echo e(asset('images/play-icon.png')); ?>">
						</div>
					</div>
				</div>
			</div>
			<div class="col-12 col-sm-6 col-md-6">
				<div class="buy-acadmy">
					<h3><?php echo e($program->title); ?></h3>
					<div class="crs-descri">
						<p><?php echo e($program->description); ?></p>
					</div>
					<div class="buy-btn-crs">
						<a class="universal-btn bdr-btn" href="#">resume</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>


<section class="module-section">
	<div class="container">
		<div class="row">
			<div class="cstm-accordion">
				<div class="panel-group">
					
					<?php $__currentLoopData = $program->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="panel panel-default panel-cstm">
						<div class="panel-heading-flat">
							<h4 class="panel-title">
								<a data-toggle="collapse" href="#module-<?php echo e($module->id); ?>">Module <?php echo e($i+1); ?>

								<span><?php echo e($module->title); ?></span>
								<i class="fa fa-caret-down" aria-hidden="true"></i>
								</a>
							</h4>
						</div>
						<div id="module-<?php echo e($module->id); ?>" class="panel-collapse collapse main-part-info">
							<div class="panel-body sub-panel-accordio">
								<div class="row">
									
									<?php $__currentLoopData = $module->chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="col-12 col-sm-6 col-md-6">
										<div class="module-info">
											<div class="panel panel-default">
												<div class="panel-heading">
													<h5 class="panel-title">
														<a data-toggle="collapse" href="#chapter-<?php echo e($chapter->id); ?>">
															<?php echo e($chapter->title); ?>

														<i class="fa fa-plus-circle" aria-hidden="true"></i>
														<i class="fa fa-minus-circle" aria-hidden="true"></i>
														</a>
													</h5>
												</div>
												<div id="chapter-<?php echo e($chapter->id); ?>" class="panel-collapse collapse sub-part-info">
													<div class="panel-body">
														<p><?php echo e($chapter->description); ?></p>
													</div>
												</div>
											</div>
										</div>
									</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								</div>
							</div>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>