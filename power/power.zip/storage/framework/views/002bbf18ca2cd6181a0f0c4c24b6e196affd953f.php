<?php $__env->startSection('content'); ?>
<section class="home-video">
	<div class="vid-sec">
		<iframe width="100%" height="315" src="<?php echo e($program->short_video); ?>?autoplay=1" frameborder="0" allowfullscreen></iframe>
	</div>
	<div class="vid-caption">
		<h2><?php echo e($program->title); ?></h2>
	</div>
</section>

<section class="main-course">
	<div class="container">
		<div class="crs-heading">
			<h2>main course</h2>
		</div>
		<div class="row">
			<div class="col-12 col-sm-6 col-md-6">
				<div class="csr-image">
					<img src="<?php echo e(asset('uploads/programs/'.$program->id.'.png')); ?>">
				</div>
			</div>
			<div class="col-12 col-sm-6 col-md-6">
				<div class="buy-acadmy">
					<h3><?php echo e($program->title); ?></h3>
					<div class="crs-descri">
						<p><?php echo e($program->description); ?></p>
					</div>
					<div class="buy-btn-crs">
						<a class="universal-btn" href="#">buy now</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>