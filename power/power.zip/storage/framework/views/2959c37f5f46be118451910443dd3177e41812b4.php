<?php $__env->startSection('content'); ?>
<section class="sub-banner">
	<div class="feature-image">
		<img src="images/our-program-bg.jpg">
		<h4>Our programs</h4>
	</div>
</section>
<section class="success-stories-page our-program">
	<div class="container">
		<div class="row">
			<?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-12 col-sm-6 col-md-6">
				<div class="prog-item">
					<img src="<?php echo e(asset('uploads/programs/'.$program->id.'.png')); ?>">
					<div class="prog-hover">
						<a href="javascript:void(0)"><?php echo e($program->title); ?></a>
						<a href="route('program.preview', [$program->slug])">View Program Preview</a>
						<a href="acadmy.html">Buy the Program</a>
					</div>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>