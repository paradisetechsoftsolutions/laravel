<div class="form-group <?php echo ($errors->has('title') ? 'has-error' : ''); ?>">
    <?php echo Form::label('title','Title', ['class' => 'control-label']); ?>

    <?php echo Form::text('title', null, ['class' => 'form-control' . ($errors->has('title') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('title', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('type') ? 'has-error' : ''); ?>">
    <?php echo Form::label('type','Type', ['class' => 'control-label']); ?>

    <?php echo Form::text('type', null, ['class' => 'form-control' . ($errors->has('type') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('type', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('price') ? 'has-error' : ''); ?>">
    <?php echo Form::label('price','Price', ['class' => 'control-label']); ?>

    <div class="input-group">
        <div class="input-group-addon">
            <i class="fa fa-usd"></i>
        </div>
        <?php echo Form::number('price', null, ['class' => 'form-control' . ($errors->has('price') ? ' is-invalid' : '') ]); ?>

        <?php echo $errors->first('price', '<span class="help-block">:message</span>'); ?>

    </div>
</div>

<div class="form-group <?php echo ($errors->has('image') ? 'has-error' : ''); ?>">
    <?php echo Form::label('image','Image', ['class' => 'control-label']); ?>

    <?php echo Form::file('image', null, ['class' => 'form-control' . ($errors->has('image') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('image', '<span class="help-block">:message</span>'); ?>

    <?php if(Request::segment(4)=='edit'): ?>
        <span class="show-image">
            <img src="<?php echo e(asset('uploads/programs/small/'.$program->id.'.png')); ?>">
        </span>
    <?php endif; ?>
</div>

<div class="form-group <?php echo ($errors->has('short_video') ? 'has-error' : ''); ?>">
    <?php echo Form::label('short_video','Short Video Link', ['class' => 'control-label']); ?>

    <?php echo Form::url('short_video', null, ['class' => 'form-control' . ($errors->has('short_video') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('short_video', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('video') ? 'has-error' : ''); ?>">
    <?php echo Form::label('video','Video Link', ['class' => 'control-label']); ?>

    <?php echo Form::url('video', null, ['class' => 'form-control' . ($errors->has('video') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('video', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('description') ? 'has-error' : ''); ?>">
    <?php echo Form::label('description','Description', ['class' => 'control-label']); ?>

    <?php echo Form::textarea('description', null, ['class' => 'form-control' . ($errors->has('description') ? ' is-invalid' : ''), 'rows' => '4' ]); ?>

    <?php echo $errors->first('description', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('active') ? 'has-error' : ''); ?>">
    <?php echo Form::label('active','Active', ['class' => 'control-label']); ?></br>
    <?php echo Form::radio('active', 1); ?> Yes
    <?php echo Form::radio('active', 0); ?> No
    <?php echo $errors->first('active', '<span class="help-block">:message</span>'); ?>

</div>