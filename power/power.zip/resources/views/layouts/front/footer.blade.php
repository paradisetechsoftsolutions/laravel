<div class="copy-right">
    © Copyright  The Powerhouse Within You 2018   |   ALL RIGHTS RESERVED  
</div>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="{{ asset('js/bootstrap.min.js') }}"></script>
<script src="{{ asset('js/slick.min.js') }}"></script>
<script src="{{ asset('js/app.js') }}"></script>
<script src="{{ asset('js/custom.js') }}"></script>
<script src="{{ asset('js/delete.js') }}"></script>
<script>var BASE_URL = jQuery('meta[name="site-url"]').attr('content');</script> 
@yield('script')
</body>
</html>